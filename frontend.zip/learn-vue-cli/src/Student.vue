<template>
  <div>
   <h3>{{Message}}</h3>
   </div>
</template>

<script>

export default {
  
  data () {
    return {
      Message : 'Welcome to Student Component'
      
    }
  },
  methods:
  {
 
  }
}
</script>

<style>

</style>
